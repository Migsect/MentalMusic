/*
 * Copyright (C) 2014, C. Ramakrishnan / Illposed Software.
 * All rights reserved.
 *
 * This code is licensed under the BSD 3-Clause license.
 * See file LICENSE (or LICENSE.html) for more information.
 */

/**
 * Provides the Java OSC API, which should be everything users of this library need.
 */
package com.illposed.osc;
